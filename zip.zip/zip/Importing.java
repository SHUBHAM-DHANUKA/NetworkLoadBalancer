import java.io.File;
import java.util.Scanner;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

class Decider extends Priority{
	public static void main(String args[]) throws Exception {
		// opening header
		      File file = new File("cosec-header");
		      Scanner inputFile = new Scanner(file);

		      // Read lines from the file until no more are left.
		      while (inputFile.hasNext())
		      {
		         System.out.println(inputFile.nextLine());
               }

		      // Close the file.
		      inputFile.close();
		   

				Priority pt = new Priority();
				//pt.DFindMethod1("sci", "1_priority");
				pt.setPriority(MAX_PRIORITY);
				//pt.start();

				Priority pt2 = new Priority();
				pt.DFindMethod1("c2c", "2_priority");
				pt2.setPriority(NORM_PRIORITY);
			
	
			Scriptertest st = new Scriptertest();
		// running decider code after every 30 second
	
			//Making class object 
		//Scriptertest st = new Scriptertest();
		//st.readBashScript();
				
		final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
        @SuppressWarnings("unused")
		final ScheduledFuture<?> taskHandle = scheduler.scheduleAtFixedRate(new Runnable() {
			
			@SuppressWarnings("deprecation")
			public void run() {
				try {
					// check any file exist in directory or not

					File tempFile = new File("/home/techie-monk/Downloads/NetworkLoadBalancer/checkFolder");
					File[] listOfFiles = tempFile.listFiles();
					if (listOfFiles.length > 0) {
						System.out.println("files exist in directory for transmission");
						// checking priority 
						File f = new File("/home/techie-monk/Downloads/NetworkLoadBalancer/checkFolder/1_priority");
						File[] listOfFiles1 = f.listFiles();
						if (listOfFiles1.length > 0 && pt.getPriority() > pt2.getPriority()) {
							System.out.println("This is highest priority file, Good Luck! ");
							st.readBashScript();

						} else {
							System.out.println(
									"Hey, This is not the highest priority file. but Dont worry You can transmit it ");
							st.readBashScript();
						}
					} else {
						System.out.println("no file for transmission");
					}
					
					
				    }catch (Exception ex) {
					ex.printStackTrace(); // or loggger would be better
				}
			}
		}, 0, 10, TimeUnit.SECONDS);
		}
	}



//**************************************************************************************************''

// check any file exist in directory or not

File tempFile = new File("/home/techie-monk/Downloads/NetworkLoadBalancer/checkFolder");
File[] listOfFiles = tempFile.listFiles();
if (listOfFiles.length > 0) {
	System.out.println("files exist in directory for transmission");
	// checking priority 
	File f = new File("/home/techie-monk/Downloads/NetworkLoadBalancer/checkFolder/1_priority");
	File[] listOfFiles1 = f.listFiles();
	if (listOfFiles1.length > 0 && pt.getPriority() > pt2.getPriority()) {
		System.out.println("This is highest priority file, Good Luck! ");
		st.readBashScript();

	} else {
		System.out.println(
				"Hey, This is not the highest priority file. but Dont worry You can transmit it ");
		st.readBashScript();
	}
} else {
	System.out.println("no file for transmission");
}


//******************************************************************8888888888

Priority pt = new Priority();
//pt.DFindMethod1("sci", "1_priority");
pt.setPriority(MAX_PRIORITY);
//pt.start();

Priority pt2 = new Priority();
pt.DFindMethod1("c2c", "2_priority");
pt2.setPriority(NORM_PRIORITY);


Scriptertest st = new Scriptertest();



