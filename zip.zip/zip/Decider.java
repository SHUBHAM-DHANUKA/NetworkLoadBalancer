import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Scanner;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.sql.*;
/**
 * @author Techie_Monk Founder of COSEC and LKI foundation
 *
 */
class Scriptertest {
	public void readBashScript() throws Exception {
		
		try {
	
				// here need to code further
				//*********************************************************************
				// database importing code 
				Class.forName("com.mysql.jdbc.Driver");
				// here nlb is database name, root is username and password
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/nlb", "root", "1996");
				
	            //record is table name
				String sql = "INSERT INTO record (ip, speed)" + "VALUES (?, ?)";

				PreparedStatement preparedStatement = con.prepareStatement(sql);
				// ********************************************************************************
				Runtime rt = Runtime.getRuntime();
				// Extract the filename and importing to bandwidth
				Process p2 = rt.exec("/home/techie-monk/Downloads/NetworkLoadBalancer/extractor.sh");
				Process p3 = rt.exec("/home/techie-monk/Downloads/NetworkLoadBalancer/extractor2.sh");
				// ********************************************************************************
				// get band width from file
				/*float bandwidth1 =0;
				float bandwidth2 =0;
				List<String> list1;
				list1 = Files.readAllLines(new File("/home/techie-monk/Downloads/NetworkLoadBalancer/bandwidth.txt").toPath(), Charset.defaultCharset() );
				bandwidth1 = Float.parseFloat(list1.get(0));
				List<String> list2; 
				list2 = Files.readAllLines(new File("/home/techie-monk/Downloads/NetworkLoadBalancer/bandwidth2.txt").toPath(), Charset.defaultCharset() );
				bandwidth2 = Float.parseFloat(list1.get(0));
				*/
				try {
				File file1 = new File("/home/techie-monk/Downloads/NetworkLoadBalancer/bandwidth.txt");
				File file2 = new File("/home/techie-monk/Downloads/NetworkLoadBalancer/bandwidth2.txt");
                BufferedReader br = new BufferedReader(new FileReader(file1)); 
                BufferedReader br2 = new BufferedReader(new FileReader(file2));
			/*	Scanner inputFile1 = new Scanner(file1);
				Scanner inputFile2 = new Scanner(file2);
				*/
                String str1="";
				String str2="";
				float bandwidth1 =0;
				float bandwidth2 =0;
				/*if(inputFile1.hasNext() && inputFile2.hasNext()) {*/
					
					str1 = br.readLine();				
					str2 = br2.readLine();
					if (str1 != null || str2 != null) {
					System.out.print(str1);
					System.out.print(str2);
					bandwidth1 = Float.parseFloat(str1);
					bandwidth2 = Float.parseFloat(str2);
				
			      br.close();
			      br2.close();
				/*inputFile1.close();
				inputFile2.close();
				*/
				// ********************************************************************************
				// checking which bandwidth is good
				// now second part of coding start from here

				if (bandwidth1 > bandwidth2) {
					File file = new File("client_listening.sh");
					Scanner inputFile = new Scanner(file);
					String ip1 = inputFile.nextLine().substring(10, 23);
					System.out.println("******************************************");
					System.out.println("Hey, you can transmit the data more fast with bandwidth1");
					System.out.println("speed is :" + bandwidth1 + "Gb/s");
					System.out.println("ip is :" + ip1);
					inputFile.close();
					
					preparedStatement.setString(1, ip1);
					preparedStatement.setFloat(2, bandwidth1);

					preparedStatement.executeUpdate();
					} 
					
				 else {

					File file = new File("client_listening2.sh");
					Scanner inputFile = new Scanner(file);	
					
					String ip2 = inputFile.nextLine().substring(10, 21);
					System.out.println("******************************************");
					System.out.println("Hey, you can transmit the data more fast with bandwidth2");
					System.out.println("speed is :" + bandwidth2 + "Gb/s");
					System.out.println("ip is :" + ip2);
					inputFile.close();
					
					
					preparedStatement.setString(1, ip2);
					preparedStatement.setFloat(2, bandwidth2);

					preparedStatement.executeUpdate();
					
				}
				
					}
				}catch(Exception e) {
					System.out.print("it is taking null value, better luck next time");
				}
				// ********************************************************************************

				p2.destroy();
				p3.destroy();
			

		

		} catch (Exception e) {
			/* handle exception */
			e.printStackTrace();
			System.out.println("Network load measuring tool is not working");
			//throw new Exception("Error " + e.getMessage(), e.getCause());
		}
	}
}
class Decider extends Priority{
	public static void main(String args[]) throws Exception {
		// opening header
		      File file = new File("cosec-header");
		      Scanner inputFile = new Scanner(file);

		      // Read lines from the file until no more are left.
		      while (inputFile.hasNext())
		      {
		         System.out.println(inputFile.nextLine());
               }

		      // Close the file.
		      inputFile.close();
		   

				Priority pt = new Priority();
				//pt.DFindMethod1("sci", "1_priority");
				pt.setPriority(MAX_PRIORITY);
				//pt.start();

				Priority pt2 = new Priority();
				pt.DFindMethod1("c2c", "2_priority");
				pt2.setPriority(NORM_PRIORITY);
			
	
			Scriptertest st = new Scriptertest();
		// running decider code after every 30 second
	
			//Making class object 
		//Scriptertest st = new Scriptertest();
		//st.readBashScript();
				
		final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
        @SuppressWarnings("unused")
		final ScheduledFuture<?> taskHandle = scheduler.scheduleAtFixedRate(new Runnable() {
			
			@SuppressWarnings("deprecation")
			public void run() {
				try {
					// check any file exist in directory or not

					File tempFile = new File("/home/techie-monk/Downloads/NetworkLoadBalancer/checkFolder");
					File[] listOfFiles = tempFile.listFiles();
					if (listOfFiles.length > 0) {
						System.out.println("files exist in directory for transmission");
						// checking priority 
						File f = new File("/home/techie-monk/Downloads/NetworkLoadBalancer/checkFolder/1_priority");
						File[] listOfFiles1 = f.listFiles();
						if (listOfFiles1.length > 0 && pt.getPriority() > pt2.getPriority()) {
							System.out.println("This is highest priority file, Good Luck! ");
							st.readBashScript();

						} else {
							System.out.println(
									"Hey, This is not the highest priority file. but Dont worry You can transmit it ");
							st.readBashScript();
						}
					} else {
						System.out.println("no file for transmission");
					}
					
					
				    }catch (Exception ex) {
					ex.printStackTrace(); // or loggger would be better
				}
			}
		}, 0, 10, TimeUnit.SECONDS);
		}
	}

