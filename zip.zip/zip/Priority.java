import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;

public class Priority extends Thread {
	public static File dir = null;
	public static FilenameFilter filter = null;

	public void DFindMethod1(String ftname, String dirname) {

		// checking Satellite files
		dir = new File("/home/techie-monk/Downloads/NetworkLoadBalancer/checkFolder");
		filter = new FilenameFilter() {
			public boolean accept(File dir, String name) {
				return name.contains(ftname);
			}
		};

		String[] children = dir.list(filter);
		if (children.length != 0) {
			for (int i = 0; i < children.length; i++) {
				String filename = children[i];
				String move = "mv  " + "/home/techie-monk/Downloads/NetworkLoadBalancer/checkFolder/" + filename + " "
						+ "/home/techie-monk/Downloads/NetworkLoadBalancer/checkFolder/" + dirname;
				Runtime rt = Runtime.getRuntime();
				try {
					rt.exec(move);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
		}
	}

	public void run() {
		System.out.println("running thread name is:" + Thread.currentThread().getName());
		System.out.println("running thread priority is:" + Thread.currentThread().getPriority());

	}

	public void PriorityMethod() {

		// ****************************************************************
		// checking Directory
		File tempFile = new File("/home/techie-monk/Downloads/NetworkLoadBalancer/checkFolder");
		boolean exists = tempFile.exists();
		if (exists) {
			System.out.println("file exist in directory for transmission");

			Priority pt = new Priority();
			pt.DFindMethod1("sci", "1_priority");
			pt.setPriority(MAX_PRIORITY);
			//pt.start();

			Priority pt2 = new Priority();
			pt.DFindMethod1("c2c", "2_priority");
			pt2.setPriority(NORM_PRIORITY);
			//pt2.start();

		} else {
			System.out.println("no file for transmission");
		}

	}
}
